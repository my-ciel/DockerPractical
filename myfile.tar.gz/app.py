# app.py
print("Hello, Docker with Python!")

